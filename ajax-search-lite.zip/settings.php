<div class="wrap" id="wpdreams"> 
<?php
  require_once(AJAXSEARCHLITE_PATH."/settings/search.php");
?>
</div>